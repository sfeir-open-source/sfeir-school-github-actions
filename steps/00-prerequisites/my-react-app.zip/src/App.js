import logo from './logo-SFEIR-blanc.png';

import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header>
      <a
        className="App-link"
        href="https://sfeir-open-source.github.io/sfeir-school-github-actions"
        target="_blank"
        rel="noopener noreferrer"
      >
        learn github actions
      </a>
    </div>
  );
}

export default App;
